#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*------------------------------------*/
bool EstPalindrome(char S[50]){
	int i,  n;
	i=0; n=strlen(S);
	while((i<=n/2)&&(S[i]==S[n-1-i])) { i++;  }
	if(i<=n/2) return false;
	return true;
}
/*-----------------------------------*/
bool EstPalindrome2(char S[50]){
	int i;int n;
	i=0; n=strlen(S);
	while(i<=n/2){
		if(S[i]!=S[n-1-i]) return false; 
		i++;
	}  
	return true;
}
/*-----------------------------------------*/
bool EstPalindrome3(char S[50]){
	int i,  j;
	i=0; j=strlen(S)-1;
	while((i<=j)&&(S[i]==S[j])) { i++; j--; }
	if(i<=j) return false;
	return true;
}
/*-----------------------------------*/
bool EstPalindrome4(char S[50]){
	int i,j;
	i=0; j=strlen(S)-1;
	while(i<=j){
		if(S[i]!=S[j]) return false; 
		i++; j--;
	}  
	return true;
}
/*---------Versions recursives-------*/
bool EstPalindromeR(char S[50], int n, int i){
	
	if((i<=n/2)&&(S[i]==S[n-1-i])) { return EstPalindromeR(S,n,i+1);  }
	else if(i<=n/2) return false;
	else return true;
}
/*-----------------------------------*/
bool EstPalindromeR2(char S[50], int n, int i){
	
	if(i<=n/2){
		if(S[i]!=S[n-1-i]) return false; 
		else return (EstPalindromeR2(S,n,i+1));
	}  
	else return true;
}
/*-----------------------------------------*/
bool EstPalindromeR3(char S[50], int i, int j){

	if((i<=j)&&(S[i]==S[j])) { return EstPalindromeR3(S, i+1, j-1); }
	if(i<=j) return false;
	return true;
}
/*-----------------------------------*/
bool EstPalindromeR4(char S[50], int i, int j){
	
	if(i<=j){
		if(S[i]!=S[j]) return false; 
		return EstPalindromeR4(S, i+1, j-1);
	}  
	return true;
}
/*------------------------------------*/
int main(){
	char S[50];
	char c;
	printf("Donner la chaine de caracteres S :"); scanf("%49s",S);
	

	printf("Est ce que %s est Palindrome :\n", S);
	printf("Reponse Methode 1  = %d\n", EstPalindrome(S));
	printf("Reponse Methode 2  = %d\n", EstPalindrome2(S));
	printf("Reponse Methode 3  = %d\n", EstPalindrome3(S));
	printf("Reponse Methode 4  = %d\n", EstPalindrome4(S));
	printf("Reponse Methode 1R = %d\n", EstPalindromeR(S,strlen(S),0));
	printf("Reponse Methode 2R = %d\n", EstPalindromeR2(S,strlen(S),0));
	printf("Reponse Methode 3R  = %d\n", EstPalindromeR3(S,0,strlen(S)-1));
	printf("Reponse Methode 4R  = %d\n", EstPalindromeR4(S,0,strlen(S)-1));
}
