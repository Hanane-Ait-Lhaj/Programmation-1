 #include <stdio.h>
#include <stdlib.h>
int pgcd(int a, int b){
	if((a % b)==0) return b;
	if(a>b) return pgcd(b,a%b);
	return pgcd(b,a);
}



int main(){
	int a, b;
	printf("Donner un entier  a : "); scanf("%d",&a);
	printf("Donner un entier  b : "); scanf("%d",&b);
	int PGCD=pgcd(a,b);
	printf("le pgcd de %d  et %d = %d\n", a,b,PGCD);
}














int pgcd2(int a, int b){
	printf("a=%d \t b=%d\n", a, b);
	if((a % b)==0){ printf("a=%d \t b=%d\n", a, b); return b; }
	if(a>b) {printf("a=%d \t b=%d\n", a, b); return pgcd2(b,a%b);	}
	return pgcd2(b,a);
}
