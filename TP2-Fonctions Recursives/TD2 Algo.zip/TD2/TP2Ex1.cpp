#include <stdio.h>
#include <stdlib.h>
int MinTab(int T[100], int n);
int MinTabR(int T[100], int n, int i, int min);
int SomTab(int T[100], int n);
int SomTabR(int T[100], int n, int i, int min);
/*-------------------------------------------*/
int MinTab(int T[100], int n){
	int i,min;
	min=T[0]; i=1;
	while(i<n){
		if(T[i]<min) min=T[i];
		i++;
	}
	return min;
}
/*-----------------------------*/
int MinTabR(int T[100], int n, int i, int min){
	if(i<n){
		if(T[i]<min) min=T[i];
		return MinTabR(T, n, i+1 , min);
	}
	return min;
}
/*-------------------------------------------*/
int SomTab(int T[100], int n){
	int i,s;
	s=0; i=0;
	while(i<n){
		s=s+T[i];
		i++;
	}
	return s;
}
/*-----------------------------*/
int SomTabR(int T[100], int n, int i, int s){
	if(i<n){
		return SomTabR(T,n,i+1,s+T[i]);
	}
	return s;
}
/*---------------------------------*/
void lectureTab(int T[100], int n){
	int i;
	for(i=0;i<n;i++){
		printf("Donner T[%d] = ",i); scanf("%d",&T[i]);
	}
}
/*----------------------------------------*/
void AfficheTab(int T[100], int n){
	int i;
	for(i=0;i<n;i++){
		printf("T[%d] = %d\n",i,T[i]);
	}
}
int main(){
	int n, m1, m2,s1,s2;
	int T[100];
	printf("Donner n = "); scanf("%d",&n);
	lectureTab(T,n);
	AfficheTab(T,n);
	//m1=MinTab(T,n); printf("min1= %d \n",m1);
	//m2=MinTabR(T,n,1,T[0]); printf("min2= %d \n",m2);
	//s1=SomTab(T,n); printf("som1= %d \n",s1);
	//s2=SomTabR(T,n,0,0); printf("som2 = %d\n",s2);
	
	//printf("min1= %d  =  min2 = %d\n",m1,m2);
	//printf("som1= %d  =  som2 = %d\n",s1,s2);
	
}
