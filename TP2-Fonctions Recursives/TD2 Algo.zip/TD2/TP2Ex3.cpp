#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*------------------------------------*/
bool existeCar(char S[50], char c){
	int i;
	i=0;
	while((i<strlen(S))&&(S[i]!=c)) { i++;  }
	if(i<strlen(S)) return true;
	return false;
}
/*-----------------------------------*/
bool existeCar2(char S[50], char c){
	int i;
	i=0;
	while(i<strlen(S)){
		if(S[i]==c) return true; 
		i++;
	}  
	return false;
}
/*---------Versions recursives-------*/
bool existeCarR(char S[50], char c, int i){
	
	if((i<strlen(S))&&(S[i]!=c)) return (existeCarR(S,c,i+1));
	if(i<strlen(S)) return true;
	return false;
}
/*------------------------------------*/
bool existeCarR2(char S[50], char c,int i){

	if(i<strlen(S)){
		if(S[i]==c) return true; 
		return (existeCarR2(S,c,i+1));
	}  
	return false;
}
/*------------------------------------*/
int main(){
	char S[50];
	char c;
	printf("Donner la chaine de caracteres S :"); scanf("%49s",S);
	
	printf("Donner le caracrtere a chercher c : ");scanf("%1s",&c);
	printf("recherche de %c dans %s\n", c,S);
	printf("Reponse Methode 1  = %d\n", existeCar(S,c));
	printf("Reponse Methode 2  = %d\n", existeCar2(S,c));
	printf("Reponse Methode 1R = %d\n", existeCarR(S,c,0));
	printf("Reponse Methode 2R = %d\n", existeCarR2(S,c,0));
}
